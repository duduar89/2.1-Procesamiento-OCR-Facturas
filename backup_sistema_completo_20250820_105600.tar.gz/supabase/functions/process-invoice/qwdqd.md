[
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6071d7bd-ab8c-4e71-b1aa-430f468418a3",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"402\", endIndex: \"411\" } ],\n    content: \"% I.V.A.\\n\"\n  },\n  confidence: 0.46527818,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.38750574, y: 0.7519732 },\n      { x: 0.44378346, y: 0.7519732 },\n      { x: 0.44378346, y: 0.7630458 },\n      { x: 0.38750574, y: 0.7630458 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "257f82d8-b943-4688-acae-08af3042e6bb",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "8a5f0db3-de07-4b4f-a6c6-a90363551568",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9498927b-5c62-4a8c-be5f-953f9e4e21d0",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "4eb15e50-9f0d-4e89-b28e-7c5efc56f7bf",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"387\", endIndex: \"402\" } ],\n    content: \"Base Imponible\\n\"\n  },\n  confidence: 0.46322048,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.2522231, y: 0.7520138 },\n      { x: 0.35507208, y: 0.7520138 },\n      { x: 0.35507208, y: 0.76397747 },\n      { x: 0.2522231, y: 0.76397747 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "8b0bf019-f472-4f29-9fb2-0f06b75df15b",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"446\", endIndex: \"452\" } ],\n    content: \"10,00\\n\"\n  },\n  confidence: 0.46527818,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.41165972, y: 0.7784783 },\n      { x: 0.44378346, y: 0.7784783 },\n      { x: 0.44378346, y: 0.7864649 },\n      { x: 0.41165972, y: 0.7864649 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "f29d5173-b7d3-43dd-bc27-edcb32f66d19",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "      Campo 12:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "f46cea5e-0586-406f-be0d-9bde13c6ebf9",
    "level": "log",
    "timestamp": 1755169344114000
  },
  {
    "event_message": "      Campo 8:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "a23fcc5e-c90e-40c8-bfc1-46a0b6e4cf90",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "90dcace4-f168-4cd5-886e-10654676b0de",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d00cd7c2-06b7-4de0-b815-c9e7c1b35ec8",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9d410a2f-fc08-40d9-b5d5-d257ea33d9da",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"336\", endIndex: \"350\" } ],\n    content: \"F. Caducidad: \"\n  },\n  confidence: 0.4903341,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.30160618, y: 0.31330553 },\n      { x: 0.37477693, y: 0.31330553 },\n      { x: 0.37477693, y: 0.32180703 },\n      { x: 0.30160618, y: 0.32180703 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "79e221c0-1244-4c11-8d7b-82d6d1c4d67d",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "632a9648-8c51-44a0-ad35-5bd2286cd93d",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"465\", endIndex: \"486\" } ],\n    content: \"Nº CUENTA SANTANDER: \"\n  },\n  confidence: 0.48321053,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.12345301, y: 0.8215292 },\n      { x: 0.31138596, y: 0.8215292 },\n      { x: 0.31138596, y: 0.83303714 },\n      { x: 0.12345301, y: 0.83303714 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9ed3fbb8-9286-4451-be45-2b611ba06e51",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "eb900926-979e-4e60-bf1f-25b036c7fc50",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "      Campo 9:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "0907e753-e0d8-4883-ae79-0404109aac38",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "      Campo 10:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "616b7b57-9251-4e86-b8ae-b062847368cf",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "4a20a06f-6b4c-4dc7-8d01-680c1bf8b8a5",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"350\", endIndex: \"359\" } ],\n    content: \"07/07/25\\n\"\n  },\n  confidence: 0.4903341,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.37834623, y: 0.31483817 },\n      { x: 0.4235574, y: 0.31483817 },\n      { x: 0.4235574, y: 0.320723 },\n      { x: 0.37834623, y: 0.320723 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "2d5b480c-9c4d-4a50-9182-172dd989d870",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9ff48ca8-6de5-46e6-bb15-74324d6aeac0",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"571\", endIndex: \"578\" } ],\n    content: \"RECIBO\\n\"\n  },\n  confidence: 0.5530207,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.18738846, y: 0.8432114 },\n      { x: 0.23854849, y: 0.8432114 },\n      { x: 0.23854849, y: 0.8520387 },\n      { x: 0.18738846, y: 0.8520387 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "8ded3277-27e4-4ef1-82d8-18c80efc2849",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"552\", endIndex: \"571\" } ],\n    content: \"Previsión de pago: \"\n  },\n  confidence: 0.5530207,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.05223391, y: 0.8412033 },\n      { x: 0.17501628, y: 0.8412033 },\n      { x: 0.17501628, y: 0.8534225 },\n      { x: 0.05223391, y: 0.8534225 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "1d613e8e-03c3-42b6-a595-5e4a0b825d0e",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"511\", endIndex: \"527\" } ],\n    content: \"Nº CUENTA BBVA: \"\n  },\n  confidence: 0.5110873,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.53718024, y: 0.82170385 },\n      { x: 0.66927534, y: 0.82170385 },\n      { x: 0.66927534, y: 0.83189285 },\n      { x: 0.53718024, y: 0.83189285 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d9e17f60-6873-4e04-9808-532bda0e55a7",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "584f1f54-4691-401c-b924-61f75cfbab50",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "72517ef2-ff05-4171-bd63-214457db59a0",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"486\", endIndex: \"511\" } ],\n    content: \"ES1600493224632214079441\\n\"\n  },\n  confidence: 0.48321053,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.3158834, y: 0.8230349 },\n      { x: 0.51814395, y: 0.8230349 },\n      { x: 0.51814395, y: 0.83144176 },\n      { x: 0.3158834, y: 0.83144176 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6ddeebc6-def0-4c83-82bb-e11c9df95325",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "2dd3dd58-a16e-406b-84c6-9c3d523297fb",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "f945a578-91c1-4cb0-ad0e-8d779b67e1dd",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d0287294-baf3-4514-a3fd-9c40906a4668",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "c5cff39b-e84e-44ed-9d91-89e7d9c6ad5e",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "      Campo 11:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "5ce77f1e-059b-4fc2-bde9-3d269d806f47",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "c75ae843-6503-4433-85de-67d8745e4704",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "7139dd8f-339c-4c9d-8ca3-f1ba9d941784",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"527\", endIndex: \"552\" } ],\n    content: \"ES4401826460810201732346\\n\"\n  },\n  confidence: 0.5110873,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.6734087, y: 0.8234552 },\n      { x: 0.876859, y: 0.8234552 },\n      { x: 0.876859, y: 0.83144176 },\n      { x: 0.6734087, y: 0.83144176 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "0894b1c2-2048-44d7-8f5b-6a1f7a3ce6b1",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9a95e9fa-6eba-44ff-ad13-99f60ee4b658",
    "level": "log",
    "timestamp": 1755169344113000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "3cdfa2d4-2bfb-4d5b-9379-5ac22e9a8e5c",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"177\", endIndex: \"184\" } ],\n    content: \"004405\\n\"\n  },\n  confidence: 0.62904173,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.5675193, y: 0.2257251 },\n      { x: 0.6127305, y: 0.2257251 },\n      { x: 0.6127305, y: 0.23581336 },\n      { x: 0.5675193, y: 0.23581336 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "433d4ba0-b2bd-496c-8071-d58b23bd02cd",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "      Campo 7:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "4a430349-920e-47a1-af22-e29afc889a09",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d4663ac6-7c91-43ba-a8f5-b63cafbc70ac",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "4328ef42-2e9b-4ac2-a323-f17e15164ee1",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "2bb5339a-0265-4281-ae13-e44d80ed6f42",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"169\", endIndex: \"177\" } ],\n    content: \"Código: \"\n  },\n  confidence: 0.62904173,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.51100534, y: 0.22641523 },\n      { x: 0.55810183, y: 0.22641523 },\n      { x: 0.55810183, y: 0.23734835 },\n      { x: 0.51100534, y: 0.23734835 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "30923c74-f70d-40b2-a08d-32db6bd39cca",
    "level": "log",
    "timestamp": 1755169344112000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"96\", endIndex: \"107\" } ],\n    content: \"30/04/2025\\n\"\n  },\n  confidence: 0.83739996,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.18262939, y: 0.1891551 },\n      { x: 0.2492564, y: 0.1891551 },\n      { x: 0.2492564, y: 0.19588062 },\n      { x: 0.18262939, y: 0.19588062 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9ae8cc37-c45c-448b-8463-b1f47262f1f3",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"126\", endIndex: \"136\" } ],\n    content: \"B56390065\\n\"\n  },\n  confidence: 0.85128117,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.18084474, y: 0.20176545 },\n      { x: 0.2492564, y: 0.20176545 },\n      { x: 0.2492564, y: 0.209752 },\n      { x: 0.18084474, y: 0.209752 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9949d868-d064-46c7-8f2a-f9a9d057eaeb",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "2056c9f9-3912-4f13-a380-e815b46eb8d1",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "f9d4ee14-637b-4c74-bcd6-7d4835a68948",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "      Campo 3:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "dae46661-203c-48b0-ba0c-f67846f04342",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"578\", endIndex: \"592\" } ],\n    content: \"Vencimientos:\\n\"\n  },\n  confidence: 0.6422234,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.65771914, y: 0.84081715 },\n      { x: 0.7515511, y: 0.84081715 },\n      { x: 0.7515511, y: 0.852048 },\n      { x: 0.65771914, y: 0.852048 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "cd716bdc-704b-45ec-b328-61cd6772dc25",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "      Campo 2:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "8e1871d9-1b88-4ccf-a496-8d0f31e98932",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"89\", endIndex: \"96\" } ],\n    content: \"FECHA:\\n\"\n  },\n  confidence: 0.83739996,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.053796384, y: 0.18839751 },\n      { x: 0.10469958, y: 0.18839751 },\n      { x: 0.10469958, y: 0.19685034 },\n      { x: 0.053796384, y: 0.19685034 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6130e8e4-ec43-4c37-9e27-08c12184efed",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "      Campo 5:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "e2716922-ced3-4ff5-8e1a-a5ec319be384",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "686f02d3-4cdb-4637-a13f-d6d5e6ec9b79",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "7fffb3fe-0dee-4313-94e0-e8fb1877a68e",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "1dac8408-28b4-4e07-91ba-c3245ded1746",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "049de3a1-f60e-4fa8-bb3f-89d985dec11d",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "      Campo 6:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "e745c205-9b38-4743-a38c-d64fef3ef92b",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Layout: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "99d0db2c-f5cc-4e44-86f4-f7436e6ecb1f",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"117\", endIndex: \"126\" } ],\n    content: \"NIF/CIF:\\n\"\n  },\n  confidence: 0.85128117,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.053416297, y: 0.20187305 },\n      { x: 0.105294466, y: 0.20187305 },\n      { x: 0.105294466, y: 0.20999037 },\n      { x: 0.053416297, y: 0.20999037 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "47067b11-1d7a-4b6c-bf09-dbf5331bf2e7",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"184\", endIndex: \"192\" } ],\n    content: \"Agente: \"\n  },\n  confidence: 0.65720403,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.4574658, y: 0.25161615 },\n      { x: 0.5052514, y: 0.25161615 },\n      { x: 0.5052514, y: 0.26250437 },\n      { x: 0.4574658, y: 0.26250437 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "bf65862f-e2bc-4896-8a48-5c0d6b2187ba",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Name: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"68\", endIndex: \"80\" } ],\n    content: \"FACTURA Nº:\\n\"\n  },\n  confidence: 0.82089734,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.05352473, y: 0.17439644 },\n      { x: 0.14165515, y: 0.17439644 },\n      { x: 0.14165515, y: 0.18332098 },\n      { x: 0.05352473, y: 0.18332098 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "0cae61c0-81ed-4e6e-9f0a-16c2f077191d",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "c5d5b55f-8ad0-4991-9ab0-78c181f1bf8a",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"592\", endIndex: \"609\" } ],\n    content: \"01/05/2025 96,80\\n\"\n  },\n  confidence: 0.6422234,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.7019631, y: 0.8591845 },\n      { x: 0.81320643, y: 0.8591845 },\n      { x: 0.81320643, y: 0.8671711 },\n      { x: 0.7019631, y: 0.8671711 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "c8ac0d55-e354-4187-a11d-66e0a93daf6a",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "834dd268-47f5-4c5c-ad42-eafb76dd9beb",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "550e2c27-9f26-4f03-a386-cf74e66a03a5",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"192\", endIndex: \"203\" } ],\n    content: \"00015 PACO\\n\"\n  },\n  confidence: 0.65720403,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.5086258, y: 0.2513661 },\n      { x: 0.5865556, y: 0.2513661 },\n      { x: 0.5865556, y: 0.26103404 },\n      { x: 0.5086258, y: 0.26103404 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "85694cec-026b-4b45-91ba-8c16e0cc29a0",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "752f4614-dd39-4a98-b44a-ec000e53c88d",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "      Campo 4:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "646fa848-4a4a-4e12-80d0-5795f7ac3935",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "db165518-d67c-490c-b01e-fdffa230dabc",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6a373ba6-5a16-42b1-bb7b-fd68b9e96118",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "0d19d739-bf02-4ba7-95c6-ed84d18cffd3",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "7b7249f6-0987-4628-9a2d-888aee53be9e",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "c9164521-b5bc-4407-bfbb-323661235bfb",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Field Value: {\n  textAnchor: {\n    textSegments: [ { startIndex: \"80\", endIndex: \"89\" } ],\n    content: \"F25/4349\\n\"\n  },\n  confidence: 0.82089734,\n  boundingPoly: {\n    normalizedVertices: [\n      { x: 0.1933373, y: 0.17570408 },\n      { x: 0.24806663, y: 0.17570408 },\n      { x: 0.24806663, y: 0.1824296 },\n      { x: 0.1933373, y: 0.1824296 }\n    ]\n  },\n  orientation: \"PAGE_UP\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "df6e1ec2-9e01-42a2-9f63-aa49f6f6d4b2",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Poly: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "5bc0ae7a-badc-4aa4-836a-183ee16eb59e",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "f2d06916-303e-4aff-b746-9ffc5e961a8a",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Bounding Box: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "47ca033b-e157-466a-afdc-153b22b40cc4",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "        - Confidence: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "151d89ca-ce06-4d05-a7f5-6acb56f8b1d3",
    "level": "log",
    "timestamp": 1755169344111000
  },
  {
    "event_message": "  - MIME Type: application/pdf\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "21f5cbd1-edeb-45b1-a20d-466a93719879",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  - Longitud texto: 834\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6c7ba3d2-51b5-46e0-9c2c-1e30a180775b",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    - Height: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "2622e50b-bdac-4342-96df-69922dfc4a95",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  - Longitud respuesta: 1023478\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "bc14f8b8-be21-423d-a40d-38276fc13696",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "      Campo 1:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "3ec8cc6b-4fc8-4315-90c9-80d4f9dc92f8",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    - Entities: 0\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d83433f3-1b69-4780-91d8-84488ef13583",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    - Form Fields: 17\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "9b0c2b3b-3ab8-4304-8fb1-7ff5e3a95405",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  📄 Página 1:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "b9e79483-51cb-4202-bc0e-3a23dd2c1fff",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  - Headers: {\n  \"alt-svc\": 'h3=\":443\"; ma=2592000,h3-29=\":443\"; ma=2592000',\n  \"content-type\": \"application/json; charset=UTF-8\",\n  date: \"Thu, 14 Aug 2025 11:02:24 GMT\",\n  server: \"scaffolding on HTTPServer2\",\n  vary: \"Origin, X-Origin, Referer\",\n  \"x-content-type-options\": \"nosniff\",\n  \"x-frame-options\": \"SAMEORIGIN\",\n  \"x-xss-protection\": \"0\"\n}\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "cd76ca6d-7bf0-4a91-8002-cdb286379738",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    - Width: undefined\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "de625d9a-95bf-4518-9bf0-1f8ad50a6c23",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  - URI: \n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "ab347b88-283a-49ec-b43e-357993518fb5",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    - Layout: 1\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "ec174228-c537-427b-888e-bc02b3f748ea",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "  - Texto presente: true\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "272db5a3-51f9-4079-b69a-e24c7cf3598c",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "    🔍 Form Fields de página 1:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "77459ea9-3b9e-4440-b0af-1be6ec72bca8",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "📋 Páginas encontradas: 1\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "6a6d3ba4-9914-4f4c-bb48-df5b0acc2ebe",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "📄 Documento encontrado en respuesta\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "d81975ce-802b-4586-856b-b202495b353b",
    "level": "log",
    "timestamp": 1755169344110000
  },
  {
    "event_message": "✅ Google AI JSON parseado correctamente\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "af52eb2e-e3ed-4b2e-a7da-f98e4ee1443b",
    "level": "log",
    "timestamp": 1755169344109000
  },
  {
    "event_message": "📊 Respuesta completa de Google AI:\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "3ca4a5de-f232-4ba5-bab5-5035078ec607",
    "level": "log",
    "timestamp": 1755169344109000
  },
  {
    "event_message": "  - Status: 200\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "4562337e-ac80-4252-9583-9a919a913812",
    "level": "log",
    "timestamp": 1755169344109000
  },
  {
    "event_message": "🔍 === DIAGNÓSTICO COMPLETO DE GOOGLE AI ===\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "42c96cd0-3cd5-4aa4-823a-bed40637cc24",
    "level": "log",
    "timestamp": 1755169344109000
  },
  {
    "event_message": "📝 Respuesta Google AI (primeros 200 chars): {\n  \"document\": {\n    \"uri\": \"\",\n    \"mimeType\": \"application/pdf\",\n    \"text\": \"HABLAMOS DE CARNE\\nArcos Ibéricos\\nQUALITY MEAT\\nCORRELIMO HUELVA S.L.\\nFACTURA Nº:\\nF25/4349\\nFECHA:\\n30/04/2025\\nCORR\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "e428b475-ca62-4ac2-8dc7-8626928a96dd",
    "level": "log",
    "timestamp": 1755169344106000
  },
  {
    "event_message": "📊 Respuesta Google Document AI - Status: 200\n",
    "event_type": "Log",
    "function_id": "1ddb8885-33cd-42c3-971e-dd10e03498a9",
    "id": "e3d59db4-b181-49ce-96d9-e1f2167e65dc",
    "level": "log",
    "timestamp": 1755169344084000
  }
]